<?php

//your email here 
$your_email = 'prospammer117@yandex.com'; 

//your password here 
$pass = 'abc';

//your username
$name = 'Mand0';


?>