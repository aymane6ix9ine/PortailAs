<?php
$lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0,2);
switch($lang){
	case 'en':
include 'langs/en.php';
break;

	case 'fr':
include 'langs/fr.php';
break;

	case 'es':
include 'langs/es.php';
break;

	case 'ru':
include 'langs/ru.php';
break;

	case 'ch':
include 'langs/ch.php';
break;


default:
include 'langs/en.php';
break;
} 
?>

